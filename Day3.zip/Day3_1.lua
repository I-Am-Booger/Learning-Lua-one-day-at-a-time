function greet()
    print("Hi, Booger!")
end

greet()
