function greet(name)
    print("Hi, " .. name .. "!")
end

greet("Gant")