function add(a, b)
    return a + b
end

result = add(5, 3)
print("5 + 3 = "  .. result) 