-- A function that prints a fun greetomg
function sayHello(name)
    print("Hello there " .. name ..", you're the coolest")
end

sayHello("Gant")

function add(x, y)
    return x + y
end

math_p = add(5, 7)
print(math_p)

function isLearningLua(name, isLearning)
    if isLearning then
        print(name .. " is crushing it with Lua!")
    else 
        print(name .. " is taking a break today")
    end
end

-- Call the isLearningLua function
isLearningLua("Nola", true)