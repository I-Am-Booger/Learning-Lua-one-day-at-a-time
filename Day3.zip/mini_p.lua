local funcs = require("mini_p_functions")

-- Are you learning Lua question
funcs.learningLuaQuestion("What language are you learning?", "Lua")
