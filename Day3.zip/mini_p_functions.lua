-- mini_p_functions.lua

local M = {} -- "module" table 

function M.learningLuaQuestion(question, correctAnswer)
    print(question)

    -- Get the user's answer 
    local userInput = io.read()

    -- Check the answer (case-insensitive)
    if string.lower(userInput) == string.lower(correctAnswer) then 
        print("Correct! You're a Lua genius 🌟")
    else 
        print("Oops! Not quite. The right answer was: " .. correctAnswer)
    end 
end

return M  -- ✅ End of this file