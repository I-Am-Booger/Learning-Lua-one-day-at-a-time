function person(name, age)
    if age < 13 then 
        print("Hi " .. name ..", you're a kid!")
    elseif age >= 13 and age <= 17 then
        print("Hey ".. name .. ", you're a teen!")
    elseif age >= 18 and age <= 65 then 
        print("Welcome, adult ".. name)
    else 
        print ("You're really old!! " .. name)
    
    end 
end

person("Gant", 65)    