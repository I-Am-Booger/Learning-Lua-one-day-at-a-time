local age = 18

if age >= 18 then 
    print("You're an adult!")
end