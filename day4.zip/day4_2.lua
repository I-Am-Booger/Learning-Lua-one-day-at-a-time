local score = 95

if score >= 90 then 
    print("A")
elseif score >= 80 then 
    print("B")
elseif score >= 70 then
    print("C")
else 
    print("Try again!")
end 