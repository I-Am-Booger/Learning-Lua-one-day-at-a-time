function grade(score)
    if score >= 90 then
        print("Grade: A")
    elseif score >= 80 then
        print("grade: B")
    elseif score >= 70 then
        print("grade: C")
    elseif score >= 60 then
        print("Grade: D")
    else 
        print("Grade: F")
    end  
end

grade(22)